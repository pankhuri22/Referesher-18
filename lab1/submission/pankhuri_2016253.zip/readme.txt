pankhuri kasliwal
2016253

I did not have a great kind of a knowledge about c and neither about pointers so google was of great help. I had to study pointers and thats why  half of my functions have pointer implementation and rest of them are implemented without pointers.
I also read about the string library on tutorials point and also got to know about a new function isspace from the c library.
I have implemented the string.h file completely along with main.c that contains implementation of some functions but not all.
string.c  file has implementation of all functions except strim and strnchr .
Implementation of some of the functions i first read on google and then tried to code on my own. 
