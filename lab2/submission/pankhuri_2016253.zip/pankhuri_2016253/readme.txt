First I took a string as an integer and space separated the string and stored it in an array using strtok that I found upon googling how to parse a string.
After this I used execvp command to run the command and passed the parameters as the path and the array in execvp.

Pankhuri kasliwal
2016253